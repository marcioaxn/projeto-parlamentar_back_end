# Release Notes

Acesse o histórico das versões publicadas e a lista de mudanças realizadas em cada uma delas, nos repositórios abaixo.

---

## Repositórios de Design

- [Diretrizes de Design](https://gitlab.com/govbr-ds/design/govbr-ds-design-diretrizes/-/releases)

- [Padrões Modelos](https://gitlab.com/govbr-ds/design/govbr-ds-design-padroes-modelos/-/releases)

- [UI-Kits](https://gitlab.com/govbr-ds/design/govbr-ds-design-uikits/-/releases)

---

## Repositórios de Desenvolvimento

- [Core](https://gitlab.com/govbr-ds/ds/dev/govbr-ds-dev-core/-/releases)
- [Web Components](https://gitlab.com/govbr-ds/dev/wbc/govbr-ds-wbc/-/releases)

- [React](https://gitlab.com/govbr-ds/dev/react/react-components/-/releases)
