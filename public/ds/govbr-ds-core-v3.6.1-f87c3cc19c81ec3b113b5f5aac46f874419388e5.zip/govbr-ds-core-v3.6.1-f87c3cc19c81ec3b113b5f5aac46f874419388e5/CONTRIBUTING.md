# Contribuindo

Os guias sobre como contribuir para o Design System GOV.BR podem ser encontrados na nossa [Wiki](https://gov.br/ds/wiki/comunidade/contribuindo-com-o-govbr-ds/).
