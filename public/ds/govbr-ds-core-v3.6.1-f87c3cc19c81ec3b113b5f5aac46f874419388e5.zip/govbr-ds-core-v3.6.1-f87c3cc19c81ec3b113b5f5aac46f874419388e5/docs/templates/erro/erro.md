*Template* (ou página) de erro são telas que retornam ao usuário uma condição específica de erro na navegação em um *site*.
