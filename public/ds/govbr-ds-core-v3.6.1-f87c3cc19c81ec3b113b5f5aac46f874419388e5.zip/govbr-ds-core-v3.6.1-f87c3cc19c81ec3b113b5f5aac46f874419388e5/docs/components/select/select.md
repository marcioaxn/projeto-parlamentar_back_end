O componente *select* permite selecionar itens em uma lista de opções.
