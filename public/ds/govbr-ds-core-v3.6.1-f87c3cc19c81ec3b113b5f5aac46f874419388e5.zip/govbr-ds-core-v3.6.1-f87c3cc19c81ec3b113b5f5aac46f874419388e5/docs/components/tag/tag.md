*Tag* é qualquer tipo de sinalizador que pode indicar um *status*, uma quantidade ou uma informação de forma precisa e direta.
