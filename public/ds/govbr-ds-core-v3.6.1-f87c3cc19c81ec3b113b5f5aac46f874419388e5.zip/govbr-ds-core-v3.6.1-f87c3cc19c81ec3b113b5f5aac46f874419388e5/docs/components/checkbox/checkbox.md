O componente *checkbox* permite selecionar uma ou mais opções em uma lista de opções.
