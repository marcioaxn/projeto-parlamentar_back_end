O componente Radio permite selecionar apenas uma opção em uma lista de opções.
