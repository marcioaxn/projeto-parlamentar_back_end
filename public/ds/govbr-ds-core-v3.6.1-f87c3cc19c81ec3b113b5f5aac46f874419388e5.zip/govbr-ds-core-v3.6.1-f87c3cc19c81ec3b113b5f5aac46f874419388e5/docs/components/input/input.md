Componente que permite a entrada de dados textuais por parte do usuário.
