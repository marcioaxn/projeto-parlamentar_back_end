São indicadores de progresso que expressam um tempo de espera não especificado ou exibem a duração de um processo.
