*Upload* é um componente que permite ao usuário selecionar um ou mais arquivos e os enviar por meio de um servidor de aplicação.
