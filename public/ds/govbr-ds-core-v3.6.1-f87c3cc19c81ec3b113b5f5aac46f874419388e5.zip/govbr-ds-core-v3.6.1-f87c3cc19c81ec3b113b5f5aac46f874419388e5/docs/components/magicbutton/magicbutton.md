O componente *Magic Button* é um botão com grande apelo visual.
