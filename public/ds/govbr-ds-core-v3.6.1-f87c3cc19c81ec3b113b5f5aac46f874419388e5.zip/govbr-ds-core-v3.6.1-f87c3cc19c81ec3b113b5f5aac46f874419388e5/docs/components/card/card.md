*Cards* são cartões (ou superfícies) que contêm conteúdo e ações diversas sobre um único assunto (ou tópico).
