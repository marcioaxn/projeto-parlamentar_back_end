<div class="br-message info" role="alert">
<div class="icon" aria-label="Informação"><i class="fas fa-info-circle fa-lg" aria-hidden="true"></i></div>
<div class="content">
<p><strong>Dependência externa.</strong></p>
<p>Este componente usa o vendor <a href="https://flatpickr.js.org/">flatpickr</a>. Em caso de dúvidas leia a documentação de <a href="/ds/guias/uso-de-vendors">Uso de Vendors</a>.</p>
</div>
</div>
</div>

*DateTimePicker* é um componente que auxilia o usuário na seleção de uma data a partir de um calendário e/ou uma hora a partir de um seletor de horas.
